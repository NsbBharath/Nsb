$(document).ready(function ()
{
	
	/*$('#username').keypress(function (e) {
				var regex = RegExp("^[a-zA-Z0-9-]+$");
				var str = String.fromCharCode(!e.charCode ? e.which : e.charCode);
			if (regex.test(str)) {
				return true;
			}
				e.preventDefault();
				return false;
			});*/

	$("#username,#password,#user_email,#cnfrm_password").keypress(function() {
		$("#fill_span").text("");
	});
			
	$(".reg").click(function ()
	{
		var user_name = $('#username').val();
		var user_pwd = $('#password').val();
		var user_cnfrmpwd = $('#cnfrm_password').val();
		var user_mail = $('#user_email').val();
		var name_config = /^[a-zA-Z0-9- ]*$/;
		var name_space = $("#username").val().replace(/\s/g, "");
		var pwd_space = $("#password").val().replace(/\s/g, "");
		var mail_config = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
		
			if (user_name=="" || user_pwd == "" || user_cnfrmpwd == "" || user_mail == "") 
			{
				$("#fill_span").text("*Please fill all fields").css('color','red');
				return false;
			} else if (!mail_config.test(user_mail))
			{
				$("#fill_span").text("*Please enter a valid mail").css('color','red');
				return false;	
			
			} else if (name_space.length==0)
			{
				$("#fill_span").text("*Empty space in username doesn't allows").css('color','red');
				$('#username').val('');
				return false;
			}
			else if (!name_config.test(user_name))
			{
				$("#fill_span").text("*Please enter a valid Username").css('color','red');
				return false;
			} else if (pwd_space.length==0)
			{
				$("#fill_span").text("*Empty space not allows in password").css('color','red');
				$('#password').val('');
				$('#cnfrm_password').val('');
				return false;
			} else if (user_pwd.length<4)
			{
				$("#fill_span").text("*Password length should be more than 3").css('color','red');
				return false;
			} else if ( user_pwd != user_cnfrmpwd)
			{
				$("#fill_span").text("*Password doesn't matches").css('color','red');
				return false;
			} else if (user_name != "" && user_pwd == user_cnfrmpwd && user_mail !="")
			{
				var datas = user_name + "," + user_mail + "," + user_pwd + "," + user_cnfrmpwd;
				localStorage.setItem("user_details",datas);
				$(location).attr('href', 'Loginuser.html');
			}	
			
	});
			
		var login_info = localStorage.getItem("user_details");
		//alert(login_info);
		var split_value = login_info.split(",");
		var name = split_value[0];
		var pwd = split_value[2];
		//alert("Name:" + name + "  " + "Password:" + pwd);
		$("#login_username").val(name);
		$("#login_password").val(pwd);
		$('.txtarea').attr('readonly', true);
				
	$("#login_button").click(function (){	
	
		var Uname = $("#login_username").val();
		var Upwd = $("#login_password").val();
		
			if( Uname == name && Upwd == pwd)
			{
				$(location).attr('href', 'chatbox1.html');
			}
			else if(Uname =="" && Upwd =="")
			{
				$("#logfill_span").text("*Enter username & password").css('color','red');
			}
			else 
			{
				$("#logfill_span").text("*Enter correct username & password").css('color','red');
			}
						
});

		var login_information = localStorage.getItem("user_details");
		//alert(login_information);
		var usersplit_value = login_information.split(",");
		var u_name = usersplit_value[0];
		$("#Login_Usrnme").html(u_name);

	$("#user1btn").click(function (){
		var x = $(".typemsg").val();
		//alert(x);
			var y = $(".typemsg").val().replace(/\s/g, "");
		//	alert(y);
			if(y.length == 0)
			{
				alert("Empty space not allowed");
				$('#reset').find('input[type=text]').val('');
			}else
			{
				$(".txtarea").append($('.typemsg').val()+'\n');
				$('#reset').find('input[type=text]').val('');
			}
	});
	$('.typemsg').keypress(function(event){

			if(event.keyCode == 13)
			{
				$("#user1btn").click();
				//event.preventDefault();
				return false;
			}			 
	});
});
	

	    //if (event.which == 32)
            //return false;
		
				//var log_info = localStorage.getItem("user_details");
		
		
		
		//var L-name= log_info.substr(0, log_info.indexOf(','));
		//var L-pwd= log_info.substr(1, log_info.indexOf(','));
		
		/*for(var i=0; i<localStorage.length, i++) {
			
			if(usr_info==localStorage.key(i)) 
			{
				$(location).attr('href', 'chatbox1.html');
				}
		
		}*/
			

/*$('.reset').on('click', function() {
    $(this).closest('form').find('input[type=text], textarea').val('');
});


/*var aux = $( "#eroare" ).val();
	$("input[name='errorSuccess2']").val(aux);
		if(type_msg!="")
		{
				$(".txtarea").html = msg_area.concat("Message:"+type_msg);
		}
		else
			alert("Type user Message");
		}
});
});	

/*function chat2()
{
	
	var s1=document.getElementById("chat3").value;
	document.getElementById("chat3").innerHTML =s1.concat("\t");
	var chat2=document.getElementById("user2").value;
	if(chat2!=""){
	document.getElementById("chat3").innerHTML = s1.concat("\t\t\t\t\t\t\t\t\t"+"User2:"+chat2+"\n");
	}else
	 alert("Type user2 conversation");
	 document.getElementById("form2").reset();
}

});			
				
			
				//$("#login_password").val=log_pwd;
			
				/*var log_name = $("#login_username").value = localStorage.getItem("usr_nme");
				var log_pwd = $("#login_password").value = localStorage.getItem("usr_cnfrmpwd");
				
				
				$("#login_username").html(log_name);
				$("#login_password").html(log_pwd);*/
				



			
				//var login_name = localStorage.getItem("usr_nme");
				//var login_pwd = localStorage.getItem("usr_cnfrmpwd");
				
				
				/*var userpassword=localStorage.getItem("usr_pwd");
				var cnfrmpassword=localStorage.getItem("usr_cnfrmpwd");
			}*/
			//if ( log_name == user_name && log_pwd == user_cnfrmpwd )
			//{
				
			//	$(location).attr('href', 'chatbox1.html');
			//}
			
			
			/*if(^[a-zA-Z0-9-]+$/.test(user_nme) == false && user_name != "")
			{
				alert("Please Enter a Valid name");
			}
			
			/*var characterReg = /^\s*[~!@#$%^&*\s]+\s*$/;
                if (!characterReg.test(usr_nme) && usr_nme != '') {
                    alert("Please enter a valid name");
                }
			
			//var val = $(this).attr('val').replace(/[!"#$%&'()*+,.\/:;<=>?@[\\\]^`{|}~]/g, "\\\\$&")
			
			if(/^[a-zA-Z0-9- ]*$/.test(usr_nme) == false) {
				alert('Your search string contains illegal characters.');
}*/
		/*if(usr_nme!="[a-zA-Z0-9- ]*$/")
		{
			alert("Please enter a valid name");
		}*/
		
