$(document).ready(function ()
{
	/*$('#username').keypress(function (e) {
				var regex = RegExp("^[a-zA-Z0-9-]+$");
				var str = String.fromCharCode(!e.charCode ? e.which : e.charCode);
			if (regex.test(str)) {
				return true;
			}
				e.preventDefault();
				return false;
			});*/
			
	
	 
			
	$(".reg").click(function ()
	{
		var user_name = $('#username').val();
		var user_pwd = $('#password').val();
		var user_cnfrmpwd = $('#cnfrm_password').val();
		var user_mail = $('#user_email').val();
		var name_config = /^[a-zA-Z0-9- ]*$/;
		var mail_config = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
			
			if (user_name=="" || user_pwd == "" || user_cnfrmpwd == "" || user_mail == "") 
			{
				alert("Please fill all fields");
				return false;
			}
			
			if (!mail_config.test(user_mail))
			{
				alert('Please enter a valid mail address');
				return false;
			}
			
			if (!name_config.test(user_name))
			{
				alert('Please enter a name without special characters');
				return false;
			}
			
		
			if ( user_pwd != user_cnfrmpwd)
			{
				$('#cnfrm_password').html('');
				$('#password').html('');
				alert("Password doesn't matches");
				return false;
			}
			
			if (user_name=="" || user_pwd == "" || user_cnfrmpwd == "" || user_mail == "") 
			{
				alert("Please fill all fields");
				return false;
			}
			if (user_name!="" && user_pwd != "" && user_cnfrmpwd != "" && user_mail != "")
			{
				var datas = user_name + "," + user_mail + "," + user_pwd + "," + user_cnfrmpwd;
				sessionStorage.setItem("user_details",datas);
				$(location).attr('href', 'Loginuser.html');
			}
			
			
			
	});
			
		var login_info = sessionStorage.getItem("user_details");
		//alert(login_info);
		var split_value = login_info.split(",");
		var name = split_value[0];
		var pwd = split_value[2];
		//alert("Name:" + name + "  " + "Password:" + pwd);
		$("#login_username").val(name);
		$("#login_password").val(pwd);
			
				//$("#login_username").find('input[type=text]').val('log_nme');
				//$("#login_password").find('input[type=password]').val('log_pwd');
				
				//$('.txtarea').append(sessionStorage.getItem('usr_nme'));
				//$('.txtarea').append(sessionStorage.getItem('usr_cnfrmpwd'));
				
				//alert('hi   ' + sessionStorage.getItem('usr_nme'));
				
	$("#login_button").click(function (){	
	
		var Uname = $("#login_username").val();
		var Upwd = $("#login_password").val();
		
		var log_info = sessionStorage.getItem("user_details");
		
		//var L-name= log_info.substr(0, log_info.indexOf(','));
		//var L-pwd= log_info.substr(1, log_info.indexOf(','));
		
			if( Uname == name && Upwd == pwd)
			{
				$(location).attr('href', 'chatbox1.html');
				//sessionStorage.setItem("user_info",log_info);
			}
			else 
			{
				alert("Wrong Username & Password");
			}
						
});
	
	
		var login_information = sessionStorage.getItem("user_details");
		//alert(login_information);
		var usersplit_value = login_information.split(",");
		var u_name = usersplit_value[0];
		$("#Login_Usrnme").html(u_name);
		
		$('.txtarea').attr('readonly', true);

	$("#user1btn").click(function(){
	
			if($('.typemsg').val()!='')
			{
				$(".txtarea").append($('.typemsg').val()+'\n');
				$('#reset').find('input[type=text]').val('');
			}
			else
			{
			alert('Please type your message');
			}
	});
	
	$('.typemsg').keypress(function(event){
			
			if(event.keyCode == 13)
			{
				$("#user1btn").click();
				//event.preventDefault();
				return false;
			}
			 
	});
});
	


/*$('.reset').on('click', function() {
    $(this).closest('form').find('input[type=text], textarea').val('');
});


/*var aux = $( "#eroare" ).val();
	$("input[name='errorSuccess2']").val(aux);
		if(type_msg!="")
		{
				$(".txtarea").html = msg_area.concat("Message:"+type_msg);
		}
		else
			alert("Type user Message");
		}
});
});	

/*function chat2()
{
	
	var s1=document.getElementById("chat3").value;
	document.getElementById("chat3").innerHTML =s1.concat("\t");
	var chat2=document.getElementById("user2").value;
	if(chat2!=""){
	document.getElementById("chat3").innerHTML = s1.concat("\t\t\t\t\t\t\t\t\t"+"User2:"+chat2+"\n");
	}else
	 alert("Type user2 conversation");
	 document.getElementById("form2").reset();
}

});			
				
			
				//$("#login_password").val=log_pwd;
			
				/*var log_name = $("#login_username").value = sessionStorage.getItem("usr_nme");
				var log_pwd = $("#login_password").value = sessionStorage.getItem("usr_cnfrmpwd");
				
				
				$("#login_username").html(log_name);
				$("#login_password").html(log_pwd);*/
				



			
				//var login_name = sessionStorage.getItem("usr_nme");
				//var login_pwd = sessionStorage.getItem("usr_cnfrmpwd");
				
				
				/*var userpassword=localStorage.getItem("usr_pwd");
				var cnfrmpassword=localStorage.getItem("usr_cnfrmpwd");
			}*/
			//if ( log_name == user_name && log_pwd == user_cnfrmpwd )
			//{
				
			//	$(location).attr('href', 'chatbox1.html');
			//}
			
			
			/*if(^[a-zA-Z0-9-]+$/.test(user_nme) == false && user_name != "")
			{
				alert("Please Enter a Valid name");
			}
			
			/*var characterReg = /^\s*[~!@#$%^&*\s]+\s*$/;
                if (!characterReg.test(usr_nme) && usr_nme != '') {
                    alert("Please enter a valid name");
                }
			
			//var val = $(this).attr('val').replace(/[!"#$%&'()*+,.\/:;<=>?@[\\\]^`{|}~]/g, "\\\\$&")
			
			if(/^[a-zA-Z0-9- ]*$/.test(usr_nme) == false) {
				alert('Your search string contains illegal characters.');
}*/
		/*if(usr_nme!="[a-zA-Z0-9- ]*$/")
		{
			alert("Please enter a valid name");
		}*/
		
